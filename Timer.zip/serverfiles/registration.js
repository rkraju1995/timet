exp=require("express")
router=exp.Router()


router.post("/register",function(req,res){
    reqbody=req.body
    //console.log(reqbody)
    email=reqbody.email;
    lid=1
con.tbl_register.find({},{_id:1}).sort({_id:-1}).limit(1,function(err,resu){
    if(resu.length==0)
    lid=1;
    else
    {
lid=resu[0]._id
lid++
    }
console.log(lid)
reqbody._id=lid
rand=Math.random()
rand=rand*10000
rand=Math.round(rand)
randstr=email+rand
reqbody.emaillink=randstr
reqbody.active=0

con.tbl_register.createIndex({username:1},{unique:1},function(err1,result1){
    if(err1)
    res.send(err1)
    else
    con.tbl_register.save(reqbody,function(err,result){
    if(err)
    res.send(err)
    else
    {
        var obj=nodemailer.createTransport({
            service:"gmail",
                auth:{
                user:"ramakrishnach018@gmail.com",
                pass:"Kiran@53"
                }
            })
                str="Your Account is created click on activation link "
                linkstr="<a href=http://localhost:4200/activate;aclink="+randstr+">Click</a>"////from this url we are sending the aclink to activate component//////
                str+=linkstr
                obj.sendMail({
                from:"ramakrishnach018@gmail.com",
                to:email,
                subject:"Account Activation Link",
                html:str
                },function(err,result){
                if(err)
                    res.send(err)
                    else
                    res.send("Registered")
                })
    }
})  
})
})
})
router.post("/activate",function(req,res){
    rdata=req.body
    con.tbl_register.update(rdata,{$set:{active:1}},function(err,result){
    res.send({response:1})
    })
})


router.post("/login",function(req,res){
    con.tbl_register.find(req.body,function(err,result){////if the data matches it will give response 1 //////
        if(result.length>=1)
        {
            con.tbl_register.find({active:1,username:req.body.username},function(err,result2){//// if username is active or not ////
                if(result2.length==1)
                {
                    str=json.sign({em:req.body.username},"*$#$%^&*")////generating web token
                    ss=req.session//////to access the session into a variable
                    ss.un=result[0].username/////creating a session veriable
                    ss.uid=result[0]._id
                    ss.token=str/////adding generated token to the session variable
                    console.log(ss.un)
                    console.log(ss.uid)
                    console.log(ss.token)
                res.send({tot:1,act:1,uid:result[0]._id,un:result[0].username,em:result[0].email,tk:str})
                }
                else
                {res.send({tot:1,act:0})}
            })
        }
        else
        {
            res.send({tot:0,act:0})////// here it will tell usename is not matches response //////
        }
    })
})

router.post("/insert",function(req,res){
    //console.log("Haiii")
    reqbody=req.body
    //console.log(reqbody)
    //console.log(req.body.uid)
    lid=1
con.tbl_timmer.find({},{_id:1}).sort({_id:-1}).limit(1,function(err,resu){
    if(resu.length==0)
    lid=1;
    else
    {
lid=resu[0]._id
lid++
    }
reqbody._id=lid

con.tbl_timmer.save(reqbody,function(err,result){
    res.send(result)
})
})
})

router.post("/gettime",function(req,res){
    //console.log("haiii")
    bdata=req.body
    //console.log(req.body)
    con.tbl_timmer.find({date:{ $regex:bdata.dt}},function(err,result){
    res.send(result)
    //console.log(result)
    })
    })

module.exports=router