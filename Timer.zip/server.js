exp=require("express");
bp=require("body-parser");
nodemailer=require("nodemailer");
json=require("jsonwebtoken")
sess=require("express-session")
app=exp()
app.use(sess({secret:"xy$%"}))
app.use(bp.json())
app.listen(1000)
mj=require("mongojs")
con=mj("mongodb://raju:raju1234@ds253203.mlab.com:53203/rk-db");


regfile=require("./serverfiles/registration")
app.use("/regref",regfile)