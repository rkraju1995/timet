
first install node_modules by : npm install 

To run back end node : nodemon server

In another Terminal : ng serve --proxy-config  proxy.json

user can login and singup

After login in user can start the timmer and stop the timmer 

User details can view by : localhost:4200/details



