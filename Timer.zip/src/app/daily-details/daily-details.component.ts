import { Component, OnInit } from '@angular/core';
import {RestService} from "../rest.service";
declare var $:any
@Component({
  selector: 'app-daily-details',
  templateUrl: './daily-details.component.html',
  styleUrls: ['./daily-details.component.css']
})
export class DailyDetailsComponent implements OnInit {
 
  constructor(public rs:RestService) { }
  timedetails
  funget(sdt){
    this.rs.timedetails(sdt).subscribe(dt=>{
      this.timedetails=dt
      alert(JSON.stringify(this.timedetails))
    })
  }

  ngOnInit()  {
    $("document").ready(()=>{
      $("#div1").datepicker({
        dateFormat:"yy-mm-dd",
        onSelect:(dt)=>{
          this.funget(dt) 
        }
      })
    })
  }

}
