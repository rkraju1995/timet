import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from "@angular/common/http";
import { RouterModule,Routes } from "@angular/router";
import {MatInputModule} from "@angular/material/input";
import {FormsModule,ReactiveFormsModule} from "@angular/forms"
import {HttpModule} from "@angular/http";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations"
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { TimmerComponent } from './timmer/timmer.component';
import { ActivationComponent } from './activation/activation.component';
import { DailyDetailsComponent } from './daily-details/daily-details.component';

const rout: Routes = [
  {path: "",component:LoginComponent},
  {path: "timmer",component:TimmerComponent},
  {path: "activate",component:ActivationComponent},
  {path: "details",component:DailyDetailsComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    TimmerComponent,
    ActivationComponent,
    DailyDetailsComponent
  ],
  imports: [
    BrowserModule,HttpClientModule,RouterModule.forRoot(rout),MatInputModule,
    FormsModule,HttpModule,BrowserAnimationsModule,ReactiveFormsModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl:'never'})
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
