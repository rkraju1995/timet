import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {RestService} from "../rest.service";


@Component({
  selector: 'app-timmer',
  templateUrl: './timmer.component.html',
  styleUrls: ['./timmer.component.css']
})
export class TimmerComponent implements OnInit {

  constructor(public rt:Router,public rs:RestService) { }

  funlogout(){
    localStorage.clear(),
    location.href="http://localhost:4200"
    this.rt.navigateByUrl("")
  }
   
  ngOnInit(){

  }
 
  time
  timeLeft: number = 0;
  interval;

  username=localStorage.getItem("un")


  startTimer() {
    this.interval = setInterval(() => {
      if(this.timeLeft < 3600) {
        this.timeLeft++;
      } else {
        this.timeLeft = 3600;
      }
    },1000)
  }

  pauseTimer() {
    clearInterval(this.interval);
    this.rs.timesave({username:this.username,time:this.timeLeft+" "+"seconds",date:new Date()}).subscribe(dt=>{
    alert("Time Saved")
    })
  }

  }

