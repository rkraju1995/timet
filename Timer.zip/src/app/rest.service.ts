import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class RestService {

  constructor(public ht:HttpClient) { }
  public dt(res:Response){
    return res;
  }

  activateaccount(var_link):Observable<any>{
    return(this.ht.post("regref/activate",{emaillink:var_link}).pipe(map(this.dt)))
  }

  loginaccount(var_object):Observable<any>{
    //alert(JSON.stringify(var_object))
    return(this.ht.post("regref/login",var_object).pipe(map(this.dt)))
  }

  timesave(object):Observable<any>{
      //alert(JSON.stringify(object))
     return(this.ht.post("regref/insert",object).pipe(map(this.dt)))
   }

   timedetails(date):Observable<any>{
    //alert(JSON.stringify(date))
   return(this.ht.post("regref/gettime",{dt:date}).pipe(map(this.dt)))
 }

}
