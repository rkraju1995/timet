import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import {RestService} from "../rest.service";
import { FormBuilder, FormGroup , Validators } from '@angular/forms';
import { PasswordValidator } from '../login/password.validator';
import {Http} from "@angular/http";
import {Router} from "@angular/router";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  rForm: FormGroup;
  post:any; 
  name:string='';
  email:string=''
  password:string='';
  retype_password: string='';
  mobile: string='';
  address: string='';

  constructor(public rt:Router,public ht:HttpClient,private fb: FormBuilder,public rs:RestService,public ht2:Http) {
    this.rForm = fb.group({
      'name':[null, Validators.required],
      'address':[null, Validators.required],
      'mobile': [null, [Validators.required, Validators.maxLength]],
      'email':[null,   [Validators.required, Validators.email]],
     'password': [null, Validators.required],
     'retype_password': [null,PasswordValidator ]
    });
   }

   var_username
   var_password
   var_email
   var_mobile
   var_address

   fun_register(){
    var obj={ 
       username:this.var_username,
       password:this.var_password,
       email:this.var_email,
       mobile:this.var_mobile,
       address:this.var_address
    }
    this.ht.post("regref/register",obj).subscribe(dt=>{
    })
    location.href="http://localhost:4200"
    alert("Registration Success click on activation link on your mail")
  }


  var_uname
  var_pwd
   ////// function Login /////// 
   funlogin(){
     
    var obj={username:this.var_uname,password:this.var_pwd}
    
    this.rs.loginaccount(obj).subscribe(dt=>{
    if(dt.tot==0)
    alert("Invalid username/password")
    else if(dt.tot==1 && dt.act==0)
    alert("Your account is not activated")
    else
    {
      localStorage.setItem("uid",dt.uid)
      localStorage.setItem("un",dt.un)
      localStorage.setItem("email",dt.em)
      localStorage.setItem("aut","1") 
      localStorage.setItem("tok",dt.tk)
      this.rt.navigateByUrl("timmer")
    }  
  })
  }


  ngOnInit() {
  }

}
